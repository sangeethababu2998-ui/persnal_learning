from flask import Flask

#import blueprints
from home.routes import home_bp
from about.routes import about_bp

app = Flask(__name__)

#register blueprints
app.register_blueprint(home_bp)
app.register_blueprint(about_bp)

if __name__ == '__main__':
    app.run(debug=True)