CREATE DATABASE SAMPLE;
USE SAMPLE;
CREATE table SAMPLES( _ID INT not null auto_increment, name varchar(100), primary key(_ID));
insert into samples (name) values ('B Sangeetha');