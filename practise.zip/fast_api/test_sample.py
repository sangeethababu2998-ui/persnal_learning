import uvicorn
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import FileResponse, JSONResponse
import fitz  # PyMuPDF
import docx
import uuid
import os

app = FastAPI()


def extract_text_from_pdf(file_bytes):
    text = ""
    with fitz.open(stream=file_bytes, filetype="pdf") as doc:
        for page in doc:
            text += page.get_text()
    return text


def extract_text_from_docx(file_bytes):
    temp_name = f"temp_{uuid.uuid4()}.docx"
    with open(temp_name, "wb") as f:
        f.write(file_bytes)

    doc = docx.Document(temp_name)
    text = "\n".join([para.text for para in doc.paragraphs])

    os.remove(temp_name)
    return text

@app.post("/upload-document/")
async def upload_file(file: UploadFile=File()):
    content = await file.read()
    filename = file.filename
    with open(f'output/{filename}','wb') as f:
        f.write(content)
    # return JSONResponse(content={'file':file.filename})

    return FileResponse(path=f"output/{filename}",media_type="application/pdf",filename="sample.pdf")
# async def upload_document(file: UploadFile = File(...)):
#     contents = await file.read()
#     filename = file.filename.lower()
#
#     if filename.endswith(".pdf"):
#         with open(f'output/{file.filename}', 'wb') as f:
#             f.write(contents)
#     elif filename.endswith(".docx"):
#         extracted_text = extract_text_from_docx(contents)
#     else:
#         raise HTTPException(status_code=400, detail="Unsupported file format. Use PDF or DOCX.")
#
#     # Save extracted content to a .txt file
#     # output_filename = f"{uuid.uuid4()}.txt"
#     # with open(output_filename, "w", encoding="utf-8") as f:
#     #     f.write(extracted_text)
#
#     # Return file as downloadable response
#     return FileResponse(
#         path=f'output/{file.filename}',
#         media_type="application/pdf",
#         filename="extracted_content.pdf",
#         background=lambda: os.remove(f'output/{file.filename}')  # auto-delete after response
#     )

if __name__=='__main__':
    uvicorn.run('test_sample:app', reload=True)