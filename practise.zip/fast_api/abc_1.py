"""
Super Simple Flask + PyJWT example

What this shows (in the simplest way):
- POST /login: checks a hard-coded user and returns a JWT if credentials match.
- GET /protected: only works when a valid JWT is sent in the Authorization header.

Why this is beginner-friendly:
- No databases, no extra libraries besides Flask and PyJWT.
- Minimal settings.
- Lots of short comments and docstrings explaining every step.

Security notes (important, even for beginners):
- Never hard-code secrets in real apps (use environment variables).
- Always use HTTPS in real apps.
- Store hashed passwords (not plain text). This is a demo only.
"""

from datetime import datetime, timedelta, timezone
from functools import wraps
from typing import Dict, Any, Optional

import jwt  # PyJWT
from flask import Flask, jsonify, request

app = Flask(__name__)

# A secret key is used to sign your JWTs so they can't be forged.
# In real life, load this from an environment variable.
SECRET_KEY = "change-this-in-production"
ALGORITHM = "HS256"

# Token expiry times: short for access tokens so they are safer if leaked
ACCESS_EXPIRES_MINUTES = 1

# A very simple "user store" just for the demo
# In real apps: use a database and store password hashes (bcrypt/argon2).
USERS: Dict[str, Dict[str, Any]] = {
    "test": {"password": "test", "roles": ["basic"]},
    "admin": {"password": "admin", "roles": ["admin"]},
    "sangeetha": {"password":"sang", "roles":["user"]}
}


def create_access_token(username: str, roles: list):
    """
    Create a signed JWT (access token) for the given user.

    What claims we include:
    - sub: who the token is about (the username)
    - roles: simple list of roles (just to demo custom data)
    - iat/exp: issued-at and expiration times to limit token lifetime
    """
    breakpoint()
    now = datetime.now(timezone.utc)
    payload = {
        "sub": username,
        "roles": roles,
        "iat": int(now.timestamp()),
        "exp": int((now + timedelta(minutes=ACCESS_EXPIRES_MINUTES)).timestamp()),
        # "exp": (now + timedelta(minutes=ACCESS_EXPIRES_MINUTES)).strftime("%Y-%m-%d %H:%M:%S")
    }
    # jwt.encode returns a string (PyJWT v2+)
    token = jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)
    return token


def decode_token(token: str) -> Dict[str, Any]:
    """
    Decode and verify a JWT.

    This checks:
    - signature (using SECRET_KEY)
    - expiration ('exp' claim)

    If anything is wrong (expired, bad signature, malformed),
    PyJWT raises an exception which we'll handle in the decorator.
    """
    payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
    return payload


def get_bearer_token_from_header() -> Optional[str]:
    """
    Read the Authorization header and extract a 'Bearer <token>' value.
    Returns the token string or None if missing.
    """
    auth = request.headers.get("Authorization", "")
    parts = auth.split()
    if len(parts) == 2 and parts[0].lower() == "bearer":
        return parts[1]
    return None


def token_required(fn):
    """
    Simple decorator to protect routes.

    What it does:
    - Looks for a Bearer token in the Authorization header.
    - Decodes and verifies the token.
    - If valid, calls the original route function.
    - If invalid/missing, returns a 401 response.
    """
    @wraps(fn)
    def wrapper(*args, **kwargs):
        token = get_bearer_token_from_header()
        if not token:
            return jsonify(error="missing_token", message="Send token in 'Authorization: Bearer <token>'"), 401
        breakpoint()
        try:
            claims = decode_token(token)
        except jwt.ExpiredSignatureError:
            return jsonify(error="token_expired", message="Token has expired"), 401
        except jwt.InvalidTokenError:
            return jsonify(error="invalid_token", message="Token is invalid"), 401

        # Optionally, verify user still exists:
        username = claims.get("sub")
        if username not in USERS:
            return jsonify(error="user_not_found", message="User no longer exists"), 401

        # Pass claims to the route if needed
        return fn(claims=claims, *args, **kwargs)

    return wrapper


@app.route("/login", methods=["POST"])
def login():
    """
    Log in with a very simple JSON body:
        { "username": "test", "password": "test" }

    If credentials match our demo users, we return a signed JWT.
    Otherwise, we send an error.

    Try with curl:
    curl -X POST http://127.0.0.1:5000/login \
         -H "Content-Type: application/json" \
         -d '{"username":"test","password":"test"}'
    """
    if not request.is_json:
        return jsonify(message="Send JSON body"), 400

    data = request.get_json(silent=True) or {}
    username = data.get("username")
    password = data.get("password")

    if not username or not password:
        return jsonify(message="username and password are required"), 400

    user = USERS.get(username)
    if not user or user["password"] != password:
        return jsonify(message="Bad username or password"), 401

    token = create_access_token(username, roles=user.get("roles", []))
    return jsonify(access_token=token), 200


@app.route("/protected", methods=["GET"])
@token_required
def protected(claims: Dict[str, Any]):
    """
    A protected route that only works with a valid token.

    Try:
    1) Get a token from /login
    2) Call:
       curl http://127.0.0.1:5000/protected -H "Authorization: Bearer <TOKEN>"
    """
    breakpoint()
    return jsonify(
        message="You are allowed to see this!",
        user=claims.get("sub"),
        roles=claims.get("roles", []),
        expires_at=claims.get("exp"),
    ), 200


@app.route("/", methods=["GET"])
def home():
    """
    Public route to verify the app works.
    """
    return jsonify(message="Welcome! Use /login to get a token, then /protected."), 200


if __name__ == "__main__":
    # For learning only; use a production server (gunicorn/uwsgi) in real deployments.
    app.run(debug=True)

