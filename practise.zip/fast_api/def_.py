from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
import jwt
from datetime import datetime, timedelta
import uvicorn
import mysql.connector

mydb = mysql.connector.connect(host="127.0.0.1", username="root", password="sang@2998", database="sample")

app = FastAPI()
security = HTTPBearer()

# Secret key and algorithm
SECRET_KEY = "your_secret_key"
ALGORITHM = "HS256"

# Dummy user
USER_DATA = {
    "admin": "password123",
    "sangeetha": "sang@2998"
}

# Create JWT token
def create_token(username: str):
    payload = {
        "sub": username,
        "exp": datetime.utcnow() + timedelta(minutes=30)
    }
    return jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)

# Verify JWT token
def verify_token(credentials: HTTPAuthorizationCredentials = Depends(security)):
    try:
        payload = jwt.decode(credentials.credentials, SECRET_KEY, algorithms=[ALGORITHM])
        return payload["sub"]
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token")
def valid(msg:str):
    mycusor = mydb.cursor()
    mycusor.execute("select password from users where password=%s", (msg,))
    item = mycusor.fetchone()
    if (item) and (msg==item[0]):
        payload = jwt.decode(msg, SECRET_KEY, algorithms=[ALGORITHM])
        return payload
    raise HTTPException(status_code=404, detail="Item not found")

# Login route
@app.post("/login")
def login(username: str, password: str):
    # if username in USER_DATA.keys() and password == USER_DATA[username]:
    token = create_token(username)
    mycursor = mydb.cursor()
    query = "insert into users (user_name, password) values (%s, %s)"
    values = (username, token)
    mycursor.execute(query, values)
    mydb.commit()
    mycursor.close()
    return {"access_token": token}
    raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")


# Protected route
@app.get("/protected")
def protected_route(user: dict = Depends(valid)):
    return {"message": f"Hello, {user['sub']}. You are authorized!"}
    raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")

if __name__=="__main__":
    uvicorn.run("def_:app", reload=True)