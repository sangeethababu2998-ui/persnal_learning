class Sample:
    name = 'stellar'
    @classmethod
    def print_s(cls):
        cls.name = "stellar_"
        print(cls.name)


obj = Sample()
