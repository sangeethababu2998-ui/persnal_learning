import uvicorn
from fastapi import FastAPI, Request, BackgroundTasks, Form
from pydantic import BaseModel

app = FastAPI()
class Item(BaseModel):
    name: str
    age: int
    location: str = None

def write_log(message:str):
    with open("log.txt", "a")as f:
        f.write(message+'\n')

@app.post('/details')
def details(item:Item):
    return item

@app.post("/send")
def send_not(name:str, background_task:BackgroundTasks):
    background_task.add_task(write_log, f"Notification sent to {name}")
    return {"message": f"Notification sent to {name}"}

@app.get("/search/{itemid}")
def search_items(itemid:int):
    return {"ID": itemid}

@app.post("/submit/")
def submit_form(name: str = Form(), age: int = Form()):
    return {"name": name, "age": age}

if __name__=="__main__":
    uvicorn.run("fast_with_pydantic_backgroundtask:app", reload=True)