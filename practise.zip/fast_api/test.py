from fastapi import FastAPI
import requests
import httpx
import uvicorn

app = FastAPI()


@app.get("/")
def root():
    return {'message': 'Welcome to GeeksforGeeks!'}


@app.get('/get_firstuser')
def first_user():
    api_url = "https://jsonplaceholder.typicode.com/users"
    all_users = requests.get(api_url).json()
    user1 = all_users[0]
    name = user1["name"]
    email = user1["email"]
    return {'name': name, "email": email}


@app.get('/get_seconduser')
async def second_user():
    api_url = "https://jsonplaceholder.typicode.com/users"
    async with httpx.AsyncClient() as client:
        response = await client.get(api_url)
        all_users = response.json()
        user2 = all_users[1]
        name = user2["name"]
        email = user2["email"]
        return {'name': name, "email": email}

if __name__=='__main__':
    uvicorn.run('test:app', reload=True)