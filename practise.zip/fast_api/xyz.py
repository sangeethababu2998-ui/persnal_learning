from fastapi import FastAPI, Depends, HTTPException
from fastapi.security import OAuth2PasswordBearer
from jose import jwt, JWTError

import uvicorn

app = FastAPI()
value = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJzYW5nZWV0aGEiLCJleHAiOjE3NTY5ODQzMzV9.gksJEnnBOVj7ESsV_FBdnWNzF0WqW8d0fkOH26D3jGg'

def valid(msg:str):
    if msg==value:
        return True
    else:
        return False

@app.post('/user')
def user(msg:str = Depends(valid)):
    if msg:
        return "authorised user"
    raise HTTPException(status_code=404, detail="user not found")



if __name__=='__main__':
    uvicorn.run("xyz:app", reload=True)

