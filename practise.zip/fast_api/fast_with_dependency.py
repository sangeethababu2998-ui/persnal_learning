import uvicorn
from fastapi import FastAPI, Depends, Header, HTTPException
from fastapi import FastAPI
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_ipaddr
from slowapi.errors import RateLimitExceeded

app = FastAPI()

def hello():
    return "Hello from Dependency"

@app.get("/")
def read_root(greeting: str = Depends(hello)):
    return {"meeting":greeting}

def verify_api_key(x_api_key: str = Header()):
    if x_api_key != 'secret123':
        return HTTPException(status_code=403, detail="Invalid API Key")

@app.get("/security")
def secure_endpoint(dep: None = Depends(verify_api_key)):
    if dep:
        return {"message": dep}
    else:
        return {"message": "Access Granted"}

class User:
    def __init__(self, name:str="Guest"):
        self.name = name

@app.get("/user")
def get_user(user: User = Depends()):
    return {"user":user.name}


if __name__=='__main__':
    uvicorn.run("fast_with_dependency:app", reload=True)