import uvicorn
from fastapi import FastAPI, Request
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded
from fastapi.responses import JSONResponse

limiter = Limiter(key_func=get_remote_address)
app = FastAPI()
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

@app.get("/hello")
@limiter.limit("1/minute")
async def sample(request:Request):
    return JSONResponse(content={"message":"hello world"})

@app.exception_handler(RateLimitExceeded)
async def custom_error(request:Request, exc:RateLimitExceeded):
    return JSONResponse(status_code=429, content={"error":"Too many responses", "details":"You've hit the limit, Please wait for some time"})


if __name__=='__main__':
    uvicorn.run("fast_with_rate_limit:app", reload=True)