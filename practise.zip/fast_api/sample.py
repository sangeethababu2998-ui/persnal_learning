import uvicorn
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import mysql.connector

# def get_connection():
#     return mysql.connector.connect(
#         host="localhost",
#         user="root",
#         password="sang@2998",
#         database="sample"
#     )
mydb = mysql.connector.connect(host="127.0.0.1", user="root", password="sang@2998", database="sample")

class Item(BaseModel):
    name: str
    description: str

app = FastAPI()

@app.post("/items/")
def create_item(item: Item):
    # conn = get_connection()
    cursor = mydb.cursor()
    query = "INSERT INTO items (name, description) VALUES (%s, %s)"
    values = (item.name, item.description)
    cursor.execute(query, values)
    mydb.commit()
    item_id = cursor.lastrowid
    cursor.close()
    # mydb.close()
    return {"id": item_id, "name": item.name, "description": item.description}

@app.get("/items/")
def get_all_items():
    # conn = get_connection()
    cursor = mydb.cursor(dictionary=True)
    cursor.execute("SELECT * FROM items")
    items = cursor.fetchall()
    cursor.close()
    # mydb.close()
    return items

@app.get("/items/{item_id}")
def get_item(item_id: int):
    # conn = get_connection()
    cursor = mydb.cursor(dictionary=True)
    cursor.execute("SELECT * FROM items WHERE id = %s", (item_id,))
    item = cursor.fetchone()
    cursor.close()
    # mydb.close()
    if item:
        return item
    raise HTTPException(status_code=404, detail="Item not found")

@app.put("/items/{item_id}")
def update_item(item_id: int, item: Item):
    # conn = get_connection()
    cursor = mydb.cursor()
    cursor.execute(
        "UPDATE items SET name = %s, description = %s WHERE id = %s",
        (item.name, item.description, item_id)
    )
    mydb.commit()
    cursor.close()
    # mydb.close()
    return {"message": "Item updated"}

@app.delete("/items/{item_id}")
def delete_item(item_id: int):
    # conn = get_connection()
    cursor = mydb.cursor()
    cursor.execute("DELETE FROM items WHERE id = %s", (item_id,))
    mydb.commit()
    cursor.close()
    # mydb.close()
    return {"message": "Item deleted"}


if __name__=='__main__':
    uvicorn.run('sample:app', reload=True)